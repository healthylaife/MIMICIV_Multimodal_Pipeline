#Notes is not tabular. Must create tabular format from the text. 


import pandas as pd
import numpy as np
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + './../..')
if not os.path.exists("./data/cohort"):
    os.makedirs("./data/cohort")

map_path = os.path.dirname(os.path.abspath(__file__)) + '/mimiciv/notes/'

pd.read_csv(map_path, header=0, delimiter="\t")













